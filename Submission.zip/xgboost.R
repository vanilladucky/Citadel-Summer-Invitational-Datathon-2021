library(dplyr)
library(xgboost)

listings <- read.csv("data/listings.csv")

listings <- listings %>%
  select(-c(
    id, 
    host_id, 
    longitude, 
    latitude, 
    zipcode
  )) %>%
  mutate(
    price = price %>% readr::parse_number(),
    weekly_price = weekly_price %>% readr::parse_number(),
    metropolitan = model.matrix(~metropolitan-1, listings),
    cancellation_policy = model.matrix(~cancellation_policy-1, listings),
    city = model.matrix(~city-1, listings), 
    property_type = model.matrix(~property_type-1, listings),
    room_type = model.matrix(~room_type-1, listings),
    state = model.matrix(~state-1, listings)
  ) %>%
  select_if(is.numeric)
  
listings$id <- 1:nrow(listings)
train <- listings %>% dplyr::sample_frac(.8)
test <- dplyr::anti_join(listings, train, by='id')

X_train <- train[, -which(names(train) %in% c("price", "id"))] %>% 
  as.matrix()
y_train <- as.numeric(train$price)

X_test <- test[, -which(names(test) %in% c("price", "id"))] %>% 
  as.matrix()
y_test <- as.numeric(test$price)

dtrain <- xgb.DMatrix(data=X_train, label=y_train)
dtest <- xgb.DMatrix(data=X_test, label=y_test)

# param <- list(booster="gblinear", objective="multi:softprob", num_class=3,
#               lambda=0.0003, alpha=0.0003, nthread=2)
# 
# bst<- xgb.train(param, dtrain, list(tr=dtrain), nrounds=70, eta=.5,
#                 callbacks=list(cb.gblinear.history()))
# for (i in 0:2) {
#   xgb.gblinear.history(bst, class_index=i) %>% matplot(type='l')
# }
# 
# bst <- xgb.cv(param, dtrain, nfold=5, nrounds=70, eta=.5,
#               callbacks=list(cb.gblinear.history(FALSE)))
# xgb.gblinear.history(bst, class_index=0)[[1]] %>% matplot(type='l')

bst <- xgboost(data=dtrain, max.depth=5, eta=1, nround=50)

pred <- predict(bst, dtest)
rmse <- sqrt(sum(pred-y_test)^2/nrow(test))